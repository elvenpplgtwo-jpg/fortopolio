// =======================
// Smooth Scroll
// =======================
const links = document.querySelectorAll('nav a');

links.forEach(link => {

    link.addEventListener('click', function(e){

        e.preventDefault();

        const id = this.getAttribute('href');

        document.querySelector(id).scrollIntoView({

            behavior:'smooth'

        });

    });

});

// =======================
// Navbar Shadow
// =======================

window.addEventListener("scroll",()=>{

    const header = document.querySelector("header");

    if(window.scrollY > 50){

        header.style.boxShadow="0 10px 25px rgba(0,0,0,.1)";

    }else{

        header.style.boxShadow="0 2px 10px rgba(0,0,0,.08)";

    }

});

// =======================
// Fade Animation
// =======================

const observer = new IntersectionObserver(entries=>{

    entries.forEach(entry=>{

        if(entry.isIntersecting){

            entry.target.classList.add("show");

        }

    });

},{
    threshold:0.2
});

document.querySelectorAll("section").forEach(section=>{

    section.classList.add("hidden");

    observer.observe(section);

});